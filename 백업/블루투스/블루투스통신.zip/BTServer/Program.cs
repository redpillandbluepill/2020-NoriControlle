﻿using InTheHand.Net;
using InTheHand.Net.Bluetooth;
using InTheHand.Net.Sockets;
using System;
using System.Net.Sockets;
using System.Security.AccessControl;
using System.Threading;
namespace BTServer
{
    // C# - 32feet.NET을 이용한 PC 간 Bluetooth 통신 예제 코드
    // http://www.sysnet.pe.kr/2/0/12004

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Guid serviceUUID = BluetoothService.TcpProtocol; // new Guid("00000004-0000-1000-8000-00805F9B34FB");

                BluetoothEndPoint bep = new BluetoothEndPoint(BluetoothAddress.None, BluetoothService.TcpProtocol);
                BluetoothListener blueListener = new BluetoothListener(bep);

                blueListener.Start();
                Console.WriteLine("Server Start Client 연결 대기중...");

                Socket socket = blueListener.AcceptSocket();
                Console.WriteLine("Client 접속 성공!");
                socket.WriteString("Sever Connect Succuss!"); //송신

                Thread sendMessage = new Thread(() => SendTread(socket)); //송신 스레드 생성, 인자는 socket 
                Thread receiveMessage = new Thread(() => ReceiveTread(socket)); //수신 스레드 생성, 인자는 socket
                
                
                sendMessage.Start(); //스레드 시작
                receiveMessage.Start(); //스레드 시작
                


            }
            catch { Console.WriteLine("연결 오류");  }
            

        }
        

        static private void SendTread(Socket socket){ //송신 스레드
            try
            {
                String sendString;
                while (true)
                {
                    sendString = Console.ReadLine(); //문자열 입력
                    socket.WriteString(sendString); //송신
                }
            }
            catch { Console.WriteLine("송신 오류"); }
        }

        static private void ReceiveTread(Socket socket) { //수신 스레드
            try
            {
                String receiveString;
                while (true)
                {
                    receiveString = socket.ReadString();
                    if (receiveString == "quit") //수신문자가 quit면 종료
                    {
                        Console.WriteLine("라즈베리와 연결이 끊겼습니다.");
                        socket.Close();
                        break;
                    }
                    else
                        Console.WriteLine("라즈베리: " + receiveString); //수신 문자열 출력
                }
            }
            catch { Console.WriteLine("수신 오류"); }
        }
    }
}
