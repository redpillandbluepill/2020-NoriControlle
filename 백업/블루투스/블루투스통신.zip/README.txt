라즈베리파이에 pybluez 설치방법 - https://fishpoint.tistory.com/3430 (파이썬을 다시 설치해야함. 시간 오래 걸림)
-> 6. pybluez 모듈 설치까지 따라하기.

BTServer - using이 안된다면 참조에서 누겟패키지인 32feet.NET을 확인 후 install 할 것
blueclient2.py - 현재 송신 스레드 구현 완료, 수신 스레드는 X

참고 사이트
파이썬 소켓통신 - https://nowonbun.tistory.com/668 (recv와 send를 그냥 쓰면 쓰레기값 발생하여 참고함)
pybluez - https://github.com/pybluez/pybluez/blob/master/examples/simple/rfcomm-client.py#L50