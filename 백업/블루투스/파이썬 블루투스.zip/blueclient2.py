#!/usr/bin/env python3
# -*- coding: utf-8 -*- 
"""PyBluez simple example rfcomm-client.py
Simple demonstration of a client application that uses RFCOMM sockets intended
for use with rfcomm-server.
Author: Albert Huang <albert@csail.mit.edu>
$Id: rfcomm-client.py 424 2006-08-24 03:35:54Z albert $
"""

import sys
import threading
import bluetooth
def send_tread(sock):
	while True:
		message=input()
		length = len(message)
		if message == 'quit':
			break
		sock.sendall(length.to_bytes(4, byteorder="little"))
		sock.sendall(message.encode('utf-8'))

def receive_tread(sock):
	while True:
		data = sock.recv(4)
		length = int.from_bytes(data, "little")
		data = sock.recv(length)
		message = data.decode('utf-8')
		print('receive: ', message)

if __name__ == "__main__":

	addr = None

	if len(sys.argv) < 2:
		print("No device specified. Searching all nearby bluetooth devices for "
		"the SampleServer service...")
	else:
		addr = sys.argv[1]
		print("Searching for SampleServer on {}...".format(addr))

	# search for the SampleServer service
	uuid = "00000004-0000-1000-8000-00805F9B34FB"
	service_matches = bluetooth.find_service(uuid=uuid, address=addr)

	if len(service_matches) == 0:
		print("Couldn't find the SampleServer service.")
		sys.exit(0)

	first_match = service_matches[0]
	port = first_match["port"]
	name = first_match["name"]
	host = first_match["host"]

	print("Connecting to \"{}\" on {}".format(name, host))

	# Create the client socket
	sock = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
	sock.connect((host, port))

	print("Connected. Type something...")
	sendMessage = threading.Thread(target=send_tread, args=(sock,))
	receiveMessage = threading.Thread(target=receive_tread, args=(sock,))
	sendMessage.start()
	receiveMessage.start()
	"""
	while True:
		message = input()
		length = len(message)
		if message == 'quit':
			 break
		sock.sendall(length.to_bytes(4, byteorder="little"))
		sock.sendall(message.encode('euc-kr'))
	"""
	
	
	#print('연결 끊어짐')
	#sock.close()


